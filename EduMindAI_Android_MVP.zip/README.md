# EduMind AI — Android MVP

## Included
- Jetpack Compose light UI
- Uzbek / English / Russian interface toggle
- Subject selection
- Image picker for textbook photos
- On-device text recognition using Google ML Kit
- Basic flashcards from recognized sentences
- Simple progress counters

## Build
1. Install Android Studio (latest stable) and Android SDK 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync and download dependencies.
4. Run on an Android device or emulator (Android 6.0+).

## Important MVP limitation
This version extracts text from images and creates basic sentence cards. It does **not** yet generate high-quality AI multiple-choice tests. That requires connecting a language-model API through a small secure backend. Do not put a private API key inside the Android app. The next development step is a backend endpoint that receives OCR text and returns validated questions, answers, explanations, and flashcards.

## Package
`com.edumind.ai`
