package com.edumind.ai

import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.launch

private val Ink = Color(0xFF24324A)
private val Blue = Color(0xFF526FE5)
private val Pale = Color(0xFFF4F6FC)
private val Muted = Color(0xFF778197)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { EduMindApp() }
    }
}

private enum class Lang { UZ, EN, RU }
private enum class Page { HOME, SCAN, CARDS, PROGRESS }

private fun tr(lang: Lang, key: String): String = when (lang) {
    Lang.UZ -> uz[key] ?: key
    Lang.EN -> en[key] ?: key
    Lang.RU -> ru[key] ?: key
}
private val uz = mapOf(
    "tag" to "AI BILAN O‘RGANISH", "headline" to "Bilimni oson o‘rgan.", "sub" to "Rasmga ol. Matnni ajrat. Yodla va o‘zingni sinab ko‘r.",
    "scan" to "Kitobni skanerla", "cards" to "Yodlash kartochkalari", "progress" to "Mening natijalarim",
    "subjects" to "Barcha fanlar", "choose" to "Fan tanlang", "history" to "Tarix", "math" to "Matematika",
    "english" to "Ingliz tili", "biology" to "Biologiya", "chemistry" to "Kimyo", "geography" to "Geografiya",
    "cameraTitle" to "Kitob sahifasini yuklang", "cameraSub" to "Rasm tanlang. EduMind matnni o‘qib beradi.",
    "pick" to "Rasm tanlash", "recognized" to "Aniqlangan matn", "noText" to "Hozircha matn yo‘q. Avval rasm tanlang.",
    "makeCards" to "Kartochkalar yaratish", "made" to "Tayyorlangan kartochkalar", "emptyCards" to "Kartochkalar hali yaratilmagan.",
    "question" to "Atama / savol", "answer" to "Matndan olingan izoh", "next" to "Keyingi", "show" to "Javobni ko‘rish",
    "home" to "Bosh sahifa", "scanTab" to "Skaner", "cardsTab" to "Yodlash", "statsTab" to "Natija",
    "notice" to "Eslatma", "noticeBody" to "Bu birinchi MVP versiyasi: rasm ichidagi matn OCR orqali olinadi. To‘liq AI test yaratish uchun xavfsiz server API ulanishi keyingi bosqichda qo‘shiladi.",
    "lines" to "Matn satrlari", "ready" to "O‘rganishni boshlashga tayyormisiz?"
)
private val en = mapOf(
    "tag" to "LEARN WITH AI", "headline" to "Make learning easier.", "sub" to "Take a photo. Extract text. Memorize and test yourself.",
    "scan" to "Scan a textbook", "cards" to "Flashcards", "progress" to "My progress", "subjects" to "All subjects",
    "choose" to "Choose a subject", "history" to "History", "math" to "Mathematics", "english" to "English",
    "biology" to "Biology", "chemistry" to "Chemistry", "geography" to "Geography",
    "cameraTitle" to "Upload a textbook page", "cameraSub" to "Choose an image. EduMind will read the text.",
    "pick" to "Choose image", "recognized" to "Recognized text", "noText" to "No text yet. Choose an image first.",
    "makeCards" to "Create flashcards", "made" to "Created flashcards", "emptyCards" to "No flashcards yet.",
    "question" to "Term / prompt", "answer" to "Explanation from text", "next" to "Next", "show" to "Show answer",
    "home" to "Home", "scanTab" to "Scanner", "cardsTab" to "Memorize", "statsTab" to "Progress",
    "notice" to "Note", "noticeBody" to "This is the first MVP: text is extracted from images using OCR. Secure server-based AI test generation will be added in the next stage.",
    "lines" to "Text lines", "ready" to "Ready to start learning?"
)
private val ru = mapOf(
    "tag" to "ОБУЧЕНИЕ С ИИ", "headline" to "Учиться проще.", "sub" to "Сфотографируй. Извлеки текст. Запоминай и проверяй себя.",
    "scan" to "Сканировать учебник", "cards" to "Карточки для запоминания", "progress" to "Мои результаты",
    "subjects" to "Все предметы", "choose" to "Выберите предмет", "history" to "История", "math" to "Математика",
    "english" to "Английский", "biology" to "Биология", "chemistry" to "Химия", "geography" to "География",
    "cameraTitle" to "Загрузите страницу учебника", "cameraSub" to "Выберите фото. EduMind распознает текст.",
    "pick" to "Выбрать фото", "recognized" to "Распознанный текст", "noText" to "Пока нет текста. Сначала выберите фото.",
    "makeCards" to "Создать карточки", "made" to "Созданные карточки", "emptyCards" to "Карточек пока нет.",
    "question" to "Термин / вопрос", "answer" to "Объяснение из текста", "next" to "Далее", "show" to "Показать ответ",
    "home" to "Главная", "scanTab" to "Сканер", "cardsTab" to "Запоминание", "statsTab" to "Результат",
    "notice" to "Примечание", "noticeBody" to "Это первая MVP-версия: текст извлекается с помощью OCR. Генерация тестов с ИИ через защищённый сервер будет добавлена на следующем этапе.",
    "lines" to "Строк текста", "ready" to "Готовы начать обучение?"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EduMindApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var lang by remember { mutableStateOf(Lang.UZ) }
    var page by remember { mutableStateOf(Page.HOME) }
    var subject by remember { mutableStateOf("history") }
    var extracted by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var cards by remember { mutableStateOf<List<String>>(emptyList()) }
    var cardIndex by remember { mutableIntStateOf(0) }
    var showAnswer by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            busy = true
            error = null
            scope.launch {
                try {
                    val image = InputImage.fromFilePath(context, uri)
                    val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                    recognizer.process(image)
                        .addOnSuccessListener { result ->
                            extracted = result.text
                            busy = false
                            if (result.text.isBlank()) error = "Matn topilmadi. Rasmni tiniqroq oling."
                        }
                        .addOnFailureListener {
                            busy = false
                            error = "Rasmni o‘qishda xatolik yuz berdi."
                        }
                } catch (e: Exception) {
                    busy = false
                    error = "Rasmni ochib bo‘lmadi."
                }
            }
        }
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Blue, onPrimary = Color.White, background = Pale,
            surface = Color.White, onSurface = Ink
        )
    ) {
        Scaffold(
            containerColor = Pale,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("EduMind AI", fontWeight = FontWeight.ExtraBold, color = Ink)
                            Text(tr(lang, "tag"), fontSize = 9.sp, color = Muted, letterSpacing = 1.5.sp)
                        }
                    },
                    actions = {
                        TextButton(onClick = { lang = when (lang) { Lang.UZ -> Lang.EN; Lang.EN -> Lang.RU; Lang.RU -> Lang.UZ } }) {
                            Text(when (lang) { Lang.UZ -> "UZ"; Lang.EN -> "EN"; Lang.RU -> "RU" }, fontWeight = FontWeight.Bold)
                        }
                    }
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(selected = page == Page.HOME, onClick = { page = Page.HOME }, icon = { Icon(Icons.Default.Home, null) }, label = { Text(tr(lang, "home")) })
                    NavigationBarItem(selected = page == Page.SCAN, onClick = { page = Page.SCAN }, icon = { Icon(Icons.Default.CameraAlt, null) }, label = { Text(tr(lang, "scanTab")) })
                    NavigationBarItem(selected = page == Page.CARDS, onClick = { page = Page.CARDS }, icon = { Icon(Icons.Default.Style, null) }, label = { Text(tr(lang, "cardsTab")) })
                    NavigationBarItem(selected = page == Page.PROGRESS, onClick = { page = Page.PROGRESS }, icon = { Icon(Icons.Default.Insights, null) }, label = { Text(tr(lang, "statsTab")) })
                }
            }
        ) { padding ->
            when (page) {
                Page.HOME -> HomePage(lang, subject, { subject = it }, { page = Page.SCAN }, { page = Page.CARDS }, Modifier.padding(padding))
                Page.SCAN -> ScanPage(lang, extracted, busy, error, { picker.launch("image/*") }, {
                    cards = makeFlashcards(extracted)
                    cardIndex = 0
                    showAnswer = false
                    page = Page.CARDS
                }, Modifier.padding(padding))
                Page.CARDS -> CardsPage(lang, cards, cardIndex, showAnswer,
                    { showAnswer = !showAnswer },
                    { if (cards.isNotEmpty()) { cardIndex = (cardIndex + 1) % cards.size; showAnswer = false } },
                    Modifier.padding(padding))
                Page.PROGRESS -> ProgressPage(lang, extracted, cards, Modifier.padding(padding))
            }
        }
    }
}

@Composable
private fun HomePage(lang: Lang, subject: String, onSubject: (String) -> Unit, onScan: () -> Unit, onCards: () -> Unit, modifier: Modifier) {
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(vertical = 18.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Ink), shape = RoundedCornerShape(26.dp)) {
                Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("✦  ${tr(lang, "tag")}", color = Color(0xFFBFCBFF), fontSize = 10.sp, letterSpacing = 1.4.sp)
                    Text(tr(lang, "headline"), color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.Bold, lineHeight = 34.sp)
                    Text(tr(lang, "sub"), color = Color(0xFFD7DEEA), fontSize = 14.sp)
                    Button(onClick = onScan, colors = ButtonDefaults.buttonColors(containerColor = Blue), modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.AddAPhoto, null); Spacer(Modifier.width(8.dp)); Text(tr(lang, "scan"))
                    }
                }
            }
        }
        item { Text(tr(lang, "choose"), color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("history", "math", "english", "biology", "chemistry", "geography").chunked(2).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { key ->
                            val label = tr(lang, key)
                            FilterChip(selected = subject == key, onClick = { onSubject(key) }, label = { Text(label) }, modifier = Modifier.weight(1f))
                        }
                        if (row.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
        item {
            FeatureCard(Icons.Default.Style, tr(lang, "cards"), "Flashcard orqali takrorlash", onCards)
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFE9EDFF)), shape = RoundedCornerShape(18.dp)) {
                Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Lightbulb, null, tint = Blue)
                    Spacer(Modifier.width(10.dp))
                    Text(tr(lang, "ready"), color = Ink, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}

@Composable
private fun FeatureCard(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String, onClick: () -> Unit) {
    Card(onClick = onClick, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Blue, modifier = Modifier.size(30.dp))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Ink, fontWeight = FontWeight.Bold)
                Text(subtitle, color = Muted, fontSize = 12.sp)
            }
            Icon(Icons.Default.ChevronRight, null, tint = Muted)
        }
    }
}

@Composable
private fun ScanPage(lang: Lang, text: String, busy: Boolean, error: String?, onPick: () -> Unit, onCards: () -> Unit, modifier: Modifier) {
    Column(modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(tr(lang, "cameraTitle"), fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text(tr(lang, "cameraSub"), color = Muted)
        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Icon(Icons.Default.DocumentScanner, null, tint = Blue, modifier = Modifier.size(54.dp))
                Text("JPG • PNG", color = Muted, fontSize = 12.sp)
                Button(onClick = onPick, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Image, null); Spacer(Modifier.width(8.dp)); Text(tr(lang, "pick"))
                }
                if (busy) CircularProgressIndicator()
            }
        }
        if (error != null) Text(error, color = MaterialTheme.colorScheme.error)
        Text(tr(lang, "recognized"), fontWeight = FontWeight.Bold, color = Ink, fontSize = 18.sp)
        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp), modifier = Modifier.weight(1f, fill = false)) {
            Text(text.ifBlank { tr(lang, "noText") }, Modifier.fillMaxWidth().padding(15.dp), color = if (text.isBlank()) Muted else Ink, fontSize = 14.sp)
        }
        if (text.isNotBlank()) {
            Button(onClick = onCards, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Style, null); Spacer(Modifier.width(8.dp)); Text(tr(lang, "makeCards"))
            }
        }
    }
}

@Composable
private fun CardsPage(lang: Lang, cards: List<String>, index: Int, showAnswer: Boolean, toggle: () -> Unit, next: () -> Unit, modifier: Modifier) {
    Column(modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text(tr(lang, "made"), fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Ink)
        if (cards.isEmpty()) {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp)) {
                Text(tr(lang, "emptyCards"), Modifier.padding(20.dp), color = Muted)
            }
        } else {
            Text("${index + 1} / ${cards.size}", color = Muted)
            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth().weight(1f)) {
                Column(Modifier.fillMaxWidth().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (showAnswer) tr(lang, "answer") else tr(lang, "question"), color = Blue, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(20.dp))
                    Text(cards[index], color = Ink, fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(20.dp))
                    OutlinedButton(onClick = toggle) { Text(if (showAnswer) tr(lang, "question") else tr(lang, "show")) }
                }
            }
            Button(onClick = next, modifier = Modifier.fillMaxWidth()) { Text(tr(lang, "next")) }
        }
    }
}

@Composable
private fun ProgressPage(lang: Lang, text: String, cards: List<String>, modifier: Modifier) {
    Column(modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(tr(lang, "progress"), fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Ink)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard(tr(lang, "lines"), text.lines().count { it.isNotBlank() }.toString(), Modifier.weight(1f))
            StatCard(tr(lang, "cards"), cards.size.toString(), Modifier.weight(1f))
        }
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFE9EDFF)), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text(tr(lang, "notice"), fontWeight = FontWeight.Bold, color = Ink)
                Spacer(Modifier.height(6.dp))
                Text(tr(lang, "noticeBody"), color = Ink, fontSize = 13.sp)
            }
        }
    }
}
@Composable
private fun StatCard(label: String, value: String, modifier: Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(value, fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Blue)
            Text(label, fontSize = 12.sp, color = Muted)
        }
    }
}

/* Starter flashcard maker: splits OCR text into readable sentence-sized cards.
   AI-generated questions and distractor answers require a secure backend integration. */
private fun makeFlashcards(raw: String): List<String> =
    raw.split(Regex("(?<=[.!?])\\s+|\\n+"))
        .map { it.trim() }
        .filter { it.length >= 35 }
        .distinct()
        .take(40)
